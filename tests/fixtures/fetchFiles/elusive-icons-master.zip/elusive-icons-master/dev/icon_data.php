<?php
    $iconData = array (
        'address-book' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'address-book-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'adjust' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'adjust-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'adult' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'align-center' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'align-justify' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'align-left' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'align-right' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'arrow-down' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'arrow-left' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'arrow-right' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'arrow-up' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'asl' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'asterisk' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'backward' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'ban-circle' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'barcode' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'behance' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'bell' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'blind' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'blogger' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'bold' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'book' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'bookmark' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'bookmark-empty' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'braille' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'briefcase' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'broom' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'brush' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'bulb' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'bullhorn' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'calendar' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'calendar-sign' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'camera' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'car' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'caret-down' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'caret-left' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'caret-right' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'caret-up' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'cc' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'certificate' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'check' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'check-empty' =>
            array (
                'categories' =>
                    array (
                        0 => 'Web Application Icons',
                    ),
                'filter' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'chevron-down' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'chevron-left' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'chevron-right' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'chevron-up' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'child' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'circle-arrow-down' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'circle-arrow-left' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'circle-arrow-right' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'circle-arrow-up' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'cloud' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'cloud-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'cog' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'cog-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'cogs' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'comment' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'comment-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'compass' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'compass-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'credit-card' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'css' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'dashboard' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'delicious' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'deviantart' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'digg' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'download' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'download-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'dribbble' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'edit' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'eject' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'envelope' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'envelope-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'error' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'error-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'eur' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'exclamation-sign' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'eye-close' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'eye-open' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'facebook' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons'
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'facetime-video' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'fast-backward' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'fast-forward' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'female' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'file' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'file-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'file-edit' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'file-edit-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'file-new' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'file-new-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'film' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'filter' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'fire' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'flag' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'flag-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'flickr' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'folder' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'folder-close' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'folder-open' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'folder-sign' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'font' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'fontsize' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'fork' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'forward' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'forward-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'foursquare' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'friendfeed' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'friendfeed-rect' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'fullscreen' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                        'arrows-alt'
                    ),
                'created' => '1.0',
            ),
        'gbp' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'gift' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'github' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'github-text' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'glass' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'glasses' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'globe' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'globe-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'googleplus' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'graph' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'graph-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'group' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'group-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'guidedog' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'hand-down' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'hand-left' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'hand-right' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'hand-up' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'hdd' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'headphones' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'hearing-impaired' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'heart' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'heart-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'heart-empty' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'home' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'home-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'hourglass' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'idea' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'idea-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'inbox' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'inbox-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'inbox-box' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'indent-left' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'indent-right' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'info-circle' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                        'info-sign'
                    ),
                'created' => '1.0',
            ),
        'instagram' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'iphone-home' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'italic' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'key' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'laptop' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'laptop-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'lastfm' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'leaf' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'lines' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'link' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'linkedin' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'list' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'list-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'livejournal' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'lock' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'lock-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'magic' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'magnet' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'male' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'map-marker' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'map-marker-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'mic' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'mic-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'minus' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'minus-sign' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'move' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'music' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'myspace' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'network' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'off' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'ok' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'ok-circle' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'ok-sign' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'opensource' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'paper-clip' =>
            array (
                'alias' =>
                    array (
                        0 => 'paperclip',
                    ),
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'paper-clip-alt' =>
            array (
                'alias' =>
                    array (
                        0 => 'paperclip-alt',
                    ),
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'path' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'pause' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'pause-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'pencil' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'pencil-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'person' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'phone' =>
            array (
                'alias' =>
                    array (
                        0 => 'earphone',
                    ),
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'phone-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'photo' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'photo-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'picasa' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'picture' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'pinterest' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'plane' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'play' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'play-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'play-circle' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'plurk' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '2.0',
            ),
        'plurk-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                        'plurk-old'
                    ),
                'created' => '2.0',
            ),
        'plus' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'plus-sign' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'podcast' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'print' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'puzzle' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'qrcode' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'question' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'question-sign' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'quote-left' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                        'quotes'
                    ),
                'created' => '1.0',
            ),
        'quote-left-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                        'quotes-alt'
                    ),
                'created' => '2.0',
            ),
        'quote-right' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                        'quotes-right'
                    ),
                'created' => '2.0',
            ),
        'quote-right-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                        'quotes-right-alt'
                    ),
                'created' => '1.0',
            ),
        'random' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'record' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'reddit' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'redux' =>
            array (
                'filter' =>
                    array (
                        'redux-framework',
                        'reduxframework'
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                        'redux-framework',
                        'reduxframework'
                    ),
                'created' => '2.0',
            ),
        'refresh' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'remove' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'remove-circle' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'remove-sign' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'repeat' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'repeat-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'resize-full' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'resize-horizontal' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'resize-small' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'resize-vertical' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'return-key' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'retweet' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'reverse-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'road' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'rss' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'scissors' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'screen' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'screen-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'screenshot' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'search' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'search-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'share' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'share-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'shopping-cart' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'shopping-cart-sign' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'signal' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'skype' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'slideshare' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'smiley' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'smiley-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'soundcloud' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'speaker' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'spotify' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'stackoverflow' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'star' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'star-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'star-empty' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'step-backward' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'step-forward' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'stop' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'stop-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'stumbleupon' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'tag' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'tags' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'tasks' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'text-height' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'text-width' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'th' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'th-large' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'th-list' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'thumbs-down' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'thumbs-up' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'time' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'time-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'tint' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'torso' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'trash' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'trash-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'tumblr' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'twitter' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'universal-access' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'unlock' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'unlock-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'upload' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'usd' =>
            array (
                'alias' =>
                    array (
                        0 => 'dollar',
                    ),
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'user' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'viadeo' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'video' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'video-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'video-chat' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'view-mode' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'vimeo' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'vkontakte' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'volume-down' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'volume-off' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'volume-up' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'w3c' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'warning-sign' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'website' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'website-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'wheelchair' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'wordpress' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                        'Brand Icons',
                    ),
                'created' => '1.0',
            ),
        'wrench' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'wrench-alt' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'youtube' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                        'Brand Icons',
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'zoom-in' =>
            array (
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
        'zoom-out' =>
            array (
                0 => 'Web Application Icons',
                'filter' =>
                    array (
                    ),
                'categories' =>
                    array (
                    ),
                'alias' =>
                    array (
                    ),
                'created' => '1.0',
            ),
    );