# Possible Categories
- Brand Icons
- Chart Icons
- Currency Icons
- Directional Icons
- File Type Icons
- Gender Icons
- Medical Icons
- Payment Icons
- Spinner Icons
- Text Editor Icons
- Transportation Icons
- Video Player Icons
- Web Application Icons

## Add as many as useful to icon_data.php.