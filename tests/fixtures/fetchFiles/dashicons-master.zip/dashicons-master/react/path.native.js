import { Path } from 'react-native-svg';

export default ( props ) => ( <Path { ...props } /> );
