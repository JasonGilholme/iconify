export default ( props ) => (
	<svg { ...props } >
		{ props.children }
	</svg>
);
