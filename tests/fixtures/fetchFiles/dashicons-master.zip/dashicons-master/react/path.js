export default ( props ) => ( <path { ...props } /> );
